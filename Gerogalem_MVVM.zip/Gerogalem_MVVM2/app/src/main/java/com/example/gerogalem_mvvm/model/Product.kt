package com.example.gerogalem_mvvm.model

data class Product(
    val id: Int,
    val name: String,
    val price: Double
)